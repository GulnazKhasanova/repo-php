<?php

namespace app\interfaces;

interface IModel
{
    public function getTablename();
    public function add();
    public function getOne($id);
    public function getAll();
    public function del();
}