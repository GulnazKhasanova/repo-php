<?php
    include "./engine/Autoload.php";
    include "./config/config.php";
  
    use app\engine\Autoload;
    use app\model\{Product,user};

    spl_autoload_register([new Autoload(),'loadClass']);

//    READ
    $product = new Product();
    $product->getOne(5);
    

    $user = new user();
    $user->getOne(1);


//CREATE
//    $product = new Product("","rem","152","RASSIA","Matreshka","1",0, "0");
//    $product->add();



    //    UPDATE

//$product->name = "";
//$product->update();/*нужно создать*/
//
////DELETE
//    $product->del();



?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        main{
            width: auto;
            height: auto;
        }
        .new_prod{
            display: flex;
            max-width: 300px;
            width: auto;
            height: 500px;
            flex-direction: column;
            justify-content: flex-start;
            margin: 20px;
        }
    </style>
</head>
<body>
<header>
    <nav>
        <ul>
            <li><a href="/my_php/catalog.php">Каталог</a></li>
            <li><a href="/my_php/basket.php">Корзина</a></li>
        </ul>
    </nav>
</header>
<main>
    <div class="new_prod">
        <form action="" method="post" enctype="multipart/form-data">
            <input type="text" name="name_prod">
            <input type="text" name="alias">
            <input type="text" name="color">
            <input type="text" name="price">
            <input type="file" name="myfile">
            <input type="submit" value="load">
        </form>
    </div>
</main>

</body>
</html>
